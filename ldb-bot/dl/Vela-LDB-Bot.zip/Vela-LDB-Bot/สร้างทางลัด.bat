@echo off
rem ASCII only inside this file. Thai text lives in msg\*.txt (printed with type).
rem
rem Why a shortcut: a .bat file cannot carry its own icon on Windows.
rem The standard way is a .lnk shortcut whose IconLocation points at an .ico file.
rem This creates "Vela - bot thon.lnk" on the Desktop pointing back at START.bat.
chcp 65001 >nul
title Vela - make shortcut
cd /d "%~dp0"
cls

echo.
type "msg\k0.txt"
echo.

if not exist "START.bat" (
  type "msg\k_miss.txt"
  echo.
  pause
  exit /b
)

rem %~dp0 ends with a backslash already - do not add another one
set "HERE=%~dp0"
set "ICO=%HERE%Vela.ico"
if not exist "%ICO%" set "ICO=%SystemRoot%\System32\shell32.dll,25"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$d=[Environment]::GetFolderPath('Desktop');" ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d 'Vela - bot thon.lnk'));" ^
  "$s.TargetPath=$env:HERE+'START.bat';" ^
  "$s.WorkingDirectory=$env:HERE;" ^
  "$s.IconLocation=$env:ICO;" ^
  "$s.Description='Vela LDB withdraw bot';" ^
  "$s.Save()"

if errorlevel 1 (
  echo.
  type "msg\k_err.txt"
  echo.
  pause
  exit /b
)

echo.
type "msg\k9.txt"
echo.
pause
