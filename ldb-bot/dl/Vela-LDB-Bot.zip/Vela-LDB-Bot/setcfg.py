#!/usr/bin/env python3
"""ตัวช่วยใส่รหัสลง config.json — วางรหัสจากหน้า Vela แล้วเขียนไฟล์ให้ถูก format 100%
   เลี่ยงการให้คนแก้ JSON เอง (ลืมลบ <<>>, Windows เติม .txt, วางผิดที่ = พังงง ๆ)
   ยิงทดสอบเชื่อมต่อทันที จะได้รู้เดี๋ยวนั้นว่ารหัสถูกไหม ไม่ต้องไปลุ้นตอนกด START
"""
import json, os, sys, hmac, hashlib, time, urllib.request, urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
CFGP = os.path.join(HERE, "config.json")


def ask(label, default=""):
    tail = (" [" + default + "]") if default else ""
    try:
        s = input(label + tail + ": ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\nยกเลิก"); sys.exit(1)
    return s or default


def clean(v):
    # ตัดช่องว่าง/บรรทัด และเครื่องหมายคำพูดที่คนอาจก๊อปติดมา
    return v.strip().strip('"').strip("'").strip()


print("=" * 44)
print("  ใส่รหัสให้บอทถอน LDB")
print("=" * 44)
print("  ไปที่หน้าแอดมิน Vela > ตั้งค่า > การ์ด 'บอทถอนอัตโนมัติ (LDB)'")
print("  > แถบ '🔑 รหัสสำหรับใส่ในบอท' แล้วกดปุ่มก๊อป")
print("  เอามาวางทีละค่า (คลิกขวาในหน้าต่างนี้ = วาง)")
print()

url = ask("Vela URL", "https://feed.yumori7.shop")
token = clean(ask("feed_token (วางแล้ว Enter)"))
secret = clean(ask("feed_secret (วางแล้ว Enter)"))

# ตรวจก่อนเขียน — บอกให้ชัดว่าตรงไหนยังไม่ถูก
errs = []
for name, v in (("feed_token", token), ("feed_secret", secret)):
    if not v:
        errs.append(name + " ยังว่าง")
    elif "<" in v or ">" in v:
        errs.append(name + " ยังมีเครื่องหมาย < > (ยังเป็นค่าตัวอย่าง ยังไม่ได้วางรหัสจริง)")
    elif not v.isascii():
        errs.append(name + " มีตัวอักษรไทย/อักขระแปลก (ก๊อปมาไม่ครบหรือผิดช่อง)")
if errs:
    print("\n[!] ยังไม่ถูก:")
    for e in errs:
        print("    - " + e)
    print("    ลองก๊อปใหม่จากหน้า Vela แล้วรันไฟล์นี้อีกครั้ง")
    sys.exit(1)

# ยิงทดสอบเชื่อมต่อจริง (action=hb ไม่กระทบคิวถอน) — รู้เดี๋ยวนั้นว่ารหัสถูกไหม
print("\nกำลังทดสอบเชื่อมต่อ Vela...")
body = json.dumps({"action": "hb", "bot": "setup"})
ts = str(int(time.time()))
sign = hmac.new(secret.encode(), (ts + "." + body).encode(), hashlib.sha256).hexdigest()
req = urllib.request.Request(
    url.rstrip("/") + "/api/feed/withdraw", data=body.encode(), method="POST",
    headers={"Content-Type": "application/json", "User-Agent": "VelaAgent/1.0",
             "X-Feed-Token": token, "X-Feed-Ts": ts, "X-Feed-Sign": sign})
ok = False
try:
    r = urllib.request.urlopen(req, timeout=20)
    data = json.loads(r.read() or "{}")
    if data.get("ok"):
        ok = True
        print("[OK] เชื่อมต่อผ่าน — รหัสถูกต้อง")
    else:
        print("[?] ต่อได้แต่ระบบตอบแปลก:", data)
except urllib.error.HTTPError as e:
    detail = ""
    try:
        detail = e.read().decode()[:120]
    except Exception:
        pass
    if e.code == 401:
        print("[!] รหัสไม่ถูก (HTTP 401) — feed_token หรือ feed_secret ผิด ก๊อปใหม่")
    else:
        print("[!] ทดสอบไม่ผ่าน HTTP", e.code, detail)
except Exception as e:
    print("[!] ต่อ Vela ไม่ได้ (เน็ต/URL):", e)

if not ok:
    ans = input("\nจะบันทึกทั้งที่ทดสอบยังไม่ผ่านไหม? (y = บันทึก / Enter = ไม่): ").strip().lower()
    if ans != "y":
        print("ไม่ได้บันทึก — แก้แล้วรันใหม่")
        sys.exit(1)

# เขียนไฟล์ — คงค่าเดิม (bot_id/poll_sec/adb/dry_run) ไว้ ถ้ามี
cfg = {}
if os.path.exists(CFGP):
    try:
        cfg = json.load(open(CFGP, encoding="utf-8"))
    except Exception:
        cfg = {}
cfg["vela_url"] = url.rstrip("/")
cfg["feed_token"] = token
cfg["feed_secret"] = secret
cfg.setdefault("bot_id", "ldb1")
cfg.setdefault("poll_sec", 5)
cfg.setdefault("adb", "adb")
cfg.setdefault("dry_run", True)
with open(CFGP, "w", encoding="utf-8") as f:
    json.dump(cfg, f, ensure_ascii=False, indent=2)
print("\n[OK] บันทึก config.json แล้ว (dry_run=%s)" % cfg["dry_run"])
print("     ต่อไปกด 'เริ่มบอท' (START.bat) ได้เลย")
