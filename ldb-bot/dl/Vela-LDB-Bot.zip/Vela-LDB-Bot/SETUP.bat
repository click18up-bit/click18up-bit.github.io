@echo off
rem ASCII only inside this file. Thai text lives in msg\*.txt (printed with type).
rem Reason: cmd mis-seeks through multi-byte UTF-8 inside .bat and runs garbage.
chcp 65001 >nul
title Vela LDB bot - first time setup
cd /d "%~dp0"
call "%~dp0_find.bat"
cls

echo.
type "msg\s0.txt"
echo.
pause

echo.
type "msg\s1.txt"
echo.
if defined ADBDIR (adb devices) else (type "msg\e_adb.txt")
echo.
type "msg\s1b.txt"
echo.
pause

echo.
type "msg\s2.txt"
echo.
if not defined ADBDIR (
  type "msg\e_adb.txt"
) else if exist "ADBKeyboard.apk" (
  adb install -r ADBKeyboard.apk
) else (
  type "msg\e_apk.txt"
)
echo.
type "msg\s2b.txt"
echo.
pause

echo.
type "msg\s3.txt"
echo.
if defined PY ("%PY%" --version) else (type "msg\e_py.txt")
echo.
pause

echo.
type "msg\s9.txt"
echo.
pause
