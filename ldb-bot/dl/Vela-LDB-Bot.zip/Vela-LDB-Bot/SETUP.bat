@echo off
rem ASCII only inside this file. Thai text lives in msg\*.txt (printed with type).
rem Reason: cmd mis-seeks through multi-byte UTF-8 inside .bat and runs garbage.
chcp 65001 >nul
title Vela LDB bot - first time setup
cd /d "%~dp0"
call "%~dp0_find.bat"
cls

echo.
type "msg\s0.txt"
echo.
pause

echo.
type "msg\s1.txt"
echo.
if defined ADBDIR (adb devices) else (type "msg\e_adb.txt")
echo.
type "msg\s1b.txt"
echo.
pause

echo.
type "msg\s2.txt"
echo.
if not defined ADBDIR (
  type "msg\e_adb.txt"
) else if exist "ADBKeyboard.apk" (
  adb install -r ADBKeyboard.apk
) else (
  type "msg\e_apk.txt"
)
echo.
type "msg\s2b.txt"
echo.
pause

echo.
type "msg\s3.txt"
echo.
if defined PY ("%PY%" --version) else (type "msg\e_py.txt")
echo.
pause

rem Put a shortcut with the Vela icon on the Desktop so the owner does not have to
rem dig into this folder every time. A .bat cannot carry its own icon - only a .lnk can.
rem Runs quietly: if it fails, setup still counts as done (START.bat works either way).
if exist "%~dp0Vela.ico" (
  set "HERE=%~dp0"
  set "ICO=%~dp0Vela.ico"
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$d=[Environment]::GetFolderPath('Desktop');" ^
    "$s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d 'Vela - bot thon.lnk'));" ^
    "$s.TargetPath=$env:HERE+'START.bat';" ^
    "$s.WorkingDirectory=$env:HERE;" ^
    "$s.IconLocation=$env:ICO;" ^
    "$s.Description='Vela LDB withdraw bot';" ^
    "$s.Save()" >nul 2>&1
)

echo.
type "msg\s9.txt"
echo.
pause
