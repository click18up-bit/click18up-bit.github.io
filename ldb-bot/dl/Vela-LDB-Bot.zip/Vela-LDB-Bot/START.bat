@echo off
rem ASCII only inside this file. Thai text lives in msg\*.txt (printed with type).
chcp 65001 >nul
title Vela LDB bot
cd /d "%~dp0"
call "%~dp0_find.bat"
cls

echo.
type "msg\r0.txt"
echo.

if not defined PY (
  type "msg\e_py.txt"
  echo.
  pause
  exit /b
)

if not exist "config.json" (
  type "msg\e_cfg.txt"
  echo.
  pause
  exit /b
)

type "msg\r1.txt"
echo.
"%PY%" ldb_agent.py --config config.json

echo.
type "msg\r9.txt"
pause >nul
