@echo off
rem ASCII only. Locates python + adb without relying on PATH.
rem Sets: PY (command or full path), ADBDIR (folder or the word PATH)

set "PY="
for %%C in (python py python3) do if not defined PY (%%C -c "import sys" >nul 2>&1 && set "PY=%%C")
if not defined PY for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do if exist "%%D\python.exe" set "PY=%%D\python.exe"
if not defined PY for /d %%D in ("%ProgramFiles%\Python3*") do if exist "%%D\python.exe" set "PY=%%D\python.exe"
if not defined PY for /d %%D in ("%ProgramFiles(x86)%\Python3*") do if exist "%%D\python.exe" set "PY=%%D\python.exe"
if not defined PY for /d %%D in ("%SystemDrive%\Python3*") do if exist "%%D\python.exe" set "PY=%%D\python.exe"
if not defined PY for /d %%D in ("%~d0\Python3*") do if exist "%%D\python.exe" set "PY=%%D\python.exe"

set "ADBDIR="
rem guide tells users to drop the bot files straight into platform-tools
if exist "%~dp0adb.exe" set "ADBDIR=%~dp0."
if not defined ADBDIR adb version >nul 2>&1 && set "ADBDIR=PATH"
if not defined ADBDIR if exist "%~dp0platform-tools\adb.exe" set "ADBDIR=%~dp0platform-tools"
if not defined ADBDIR if exist "%~dp0..\platform-tools\adb.exe" set "ADBDIR=%~dp0..\platform-tools"
if not defined ADBDIR if exist "%USERPROFILE%\Downloads\platform-tools\adb.exe" set "ADBDIR=%USERPROFILE%\Downloads\platform-tools"
if not defined ADBDIR if exist "%USERPROFILE%\Desktop\platform-tools\adb.exe" set "ADBDIR=%USERPROFILE%\Desktop\platform-tools"
if not defined ADBDIR if exist "%~d0\platform-tools\adb.exe" set "ADBDIR=%~d0\platform-tools"
if not defined ADBDIR if exist "%SystemDrive%\platform-tools\adb.exe" set "ADBDIR=%SystemDrive%\platform-tools"
if defined ADBDIR if not "%ADBDIR%"=="PATH" set "PATH=%ADBDIR%;%PATH%"

exit /b
