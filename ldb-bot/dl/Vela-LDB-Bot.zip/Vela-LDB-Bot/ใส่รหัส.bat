@echo off
rem ASCII only. Thai lives in setcfg.py (python reads utf-8 fine; cmd does not).
chcp 65001 >nul
title Vela LDB bot - set keys
cd /d "%~dp0"
call "%~dp0_find.bat"
cls

if not defined PY (
  type "msg\e_py.txt"
  echo.
  pause
  exit /b
)

"%PY%" setcfg.py

echo.
pause
