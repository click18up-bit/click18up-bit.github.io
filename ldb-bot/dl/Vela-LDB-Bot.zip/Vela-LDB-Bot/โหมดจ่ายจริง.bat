@echo off
rem ASCII only. Thai lives in setmode.py.
chcp 65001 >nul
title Vela LDB bot - mode
cd /d "%~dp0"
call "%~dp0_find.bat"
cls

if not defined PY (
  type "msg\e_py.txt"
  echo.
  pause
  exit /b
)

"%PY%" setmode.py

echo.
pause
