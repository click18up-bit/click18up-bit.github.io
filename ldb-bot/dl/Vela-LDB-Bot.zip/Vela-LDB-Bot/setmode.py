#!/usr/bin/env python3
"""สลับโหมดบอท: ทดสอบ (dry_run) <-> จ่ายจริง — ไม่ต้องแก้ config.json มือ
   เปิดจ่ายจริงคือสวิตช์อันตราย (เงินออกเรียกคืนไม่ได้) จึงบังคับพิมพ์ยืนยัน
   dry_run=True  : บอทเดินถึงหน้ายืนยัน + พิสูจน์ แล้วหยุด ไม่กดจ่าย (ปลอดภัย ทดสอบได้)
   dry_run=False : บอทกดจ่ายจริง (ต้องเปิดสวิตช์ wd_bot_enabled ฝั่ง Vela ด้วยถึงจะทำงาน)
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
CFGP = os.path.join(HERE, "config.json")

if not os.path.exists(CFGP):
    print("[!] ยังไม่มี config.json — กด 'ใส่รหัส' ก่อน")
    sys.exit(1)

try:
    cfg = json.load(open(CFGP, encoding="utf-8"))
except Exception as e:
    print("[!] อ่าน config.json ไม่ได้:", e)
    sys.exit(1)

cur = bool(cfg.get("dry_run", True))
print("=" * 44)
print("  โหมดบอทถอน LDB")
print("=" * 44)
if cur:
    print("  ตอนนี้: 🧪 โหมดทดสอบ (dry_run) — บอทไม่กดจ่ายจริง")
    print()
    print("  จะเปลี่ยนเป็น 💵 จ่ายเงินจริง")
    print("  * เงินจะออกจากบัญชีธนาคารจริง เรียกคืนไม่ได้")
    print("  * บอทจะจ่ายก็ต่อเมื่อเปิดสวิตช์ wd_bot_enabled ฝั่ง Vela ด้วย")
    print()
    ans = input("  ยืนยันเปิดจ่ายจริง? พิมพ์  JAI  แล้ว Enter (อย่างอื่น = ยกเลิก): ").strip()
    if ans != "JAI":
        print("\n  ยกเลิก — ยังเป็นโหมดทดสอบเหมือนเดิม")
        sys.exit(0)
    cfg["dry_run"] = False
    msg = "💵 จ่ายเงินจริง"
else:
    print("  ตอนนี้: 💵 จ่ายเงินจริง")
    print()
    print("  จะเปลี่ยนกลับเป็น 🧪 โหมดทดสอบ (dry_run) — บอทหยุดกดจ่าย")
    ans = input("  ยืนยันปิดจ่ายจริง? (y = ปิด / Enter = ไม่): ").strip().lower()
    if ans != "y":
        print("\n  ยกเลิก — ยังจ่ายจริงเหมือนเดิม")
        sys.exit(0)
    cfg["dry_run"] = True
    msg = "🧪 โหมดทดสอบ (dry_run)"

with open(CFGP, "w", encoding="utf-8") as f:
    json.dump(cfg, f, ensure_ascii=False, indent=2)
print("\n[OK] เปลี่ยนเป็น " + msg + " แล้ว")
print("     ปิดบอทที่รันอยู่ (ถ้ามี) แล้วกด 'เริ่มบอท' ใหม่ให้โหมดมีผล")
