#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ldb_agent.py — ตัวกลางบอทถอน LDB (รันบนคอม Windows ขับมือถือผ่าน adb/USB)

ทำอะไร (ต่อ 1 ใบถอน):
  1) ดึงงานจาก Vela: POST /api/feed/withdraw {action:claim}  (โทเคน + ลายเซ็น HMAC)
     ได้ job {id,payout,currency,bank,acctNo,acctName} + cfg {model,srcAcct,srcName,pin}
  2) ขับแอป LDB: Transfer → กรอกเลขบัญชี (ADBKeyboard) → Next → กรอกยอด → Next
  3) 🔴 ประตูพิสูจน์ที่หน้า Confirm: เทียบ ชื่อผู้รับ + เลขบัญชี + ยอด + บัญชีต้นทาง
        ตรงครบ → กด Confirm → ใส่ PIN → หน้าสำเร็จ · ไม่ตรง → ยกเลิก + รายงาน fail
  4) อ่านเลขอ้างอิง (FT..) + กดปุ่ม Save ดึงรูปสลิป → ส่งกลับ Vela: action=sent (ref+slip)

ปลอดภัย: สุ่มตำแหน่งแตะ + สุ่มหน่วงเวลา · ประตูพิสูจน์ก่อนกดจ่ายเสมอ ·
         DRY_RUN=1 = ทำทุกอย่างถึงหน้า Confirm แล้ว "หยุด ไม่กดจ่าย" (คืนใบเข้าคิว) — ใช้ทดสอบ

รันบน stdlib ล้วน (ไม่ต้องลง pip อะไร) — ต้องมี adb ใน PATH + มือถือต่อ USB (authorized)
  python ldb_agent.py --config config.json
  python ldb_agent.py --config config.json --once        # ทำงานรอบเดียวแล้วออก
  python ldb_agent.py --config config.json --selftest     # แค่ทดสอบว่าอ่าน/นำทางมือถือได้
"""
import argparse, base64, hashlib, hmac, json, os, random, re, shlex, subprocess as sp, sys, time, urllib.request, urllib.error

# ───────────────────────── config ─────────────────────────
CFG = {
    "vela_url": "https://feed.yumori7.shop",
    "feed_token": "",
    "feed_secret": "",
    "bot_id": "ldb1",
    "poll_sec": 5,
    "adb": "adb",
    "ldb_pkg": "com.ldb.wallet",
    "slip_dir": "/sdcard/Pictures/LDB Trust",
    "dry_run": True,          # 🔴 เริ่มต้น = ทดสอบ ไม่โอนจริง · ตั้ง false เมื่อพร้อมยิงจริง
    "adbkeyboard_ime": "com.android.adbkeyboard/.AdbIME",
    "transfer_desc": "Transfer",
    "restart_every_sec": 150,   # เปิดแอปค้างเกินเท่านี้ = kill แล้วเปิดใหม่+login (กัน LDB เพี้ยน/LAPNET)
                                # 🔴 เจ้าของยืนยัน 17 ส.ค.: LDB เปิดค้างแค่ 5-10 นาทีก็เพี้ยน → ตั้ง 2.5 นาที เผื่อ margin
}
ADB = ["adb"]

# รหัสธนาคารจาก Vela (bank_code) → คำที่ "ไม่ซ้ำใคร" ใน content-desc หน้าเลือกธนาคารของแอป LDB
# (map สดจากเครื่องจริง 17 ส.ค. 2026) — ชื่อในแอปเป็นภาษาอังกฤษเต็ม เทียบแบบ substring ตัวพิมพ์เล็ก
#   ⚠️ BCEL ในแอป = "Banque Pour Le Commerce Exterieur Lao Public" (ไม่มีคำว่า BCEL!)
#   ⚠️ LDB ไม่อยู่ในลิสต์ = โอนในธนาคารเดียวกัน ข้ามหน้าเลือกธนาคาร (ไปหน้ายอดเลย)
#   Vela code : คำที่ "ไม่ซ้ำใคร" ใน content-desc หน้าเลือกธนาคาร (พิมพ์เล็ก) · เลข = ลำดับในแอป
#   ⭐ map สดครบ 19 ธนาคารจากเครื่องจริง 17 ส.ค. 2026 — ยึดชื่อในแอป LDB เป็นหลัก Vela ตั้งให้ตรง
BANK_MATCH = {
    "BCEL":   "commerce exterieur",         # 01 การค้าต่างประเทศ (ในแอปเป็นชื่อฝรั่งเศส ไม่มีคำว่า BCEL!)
    "APB":    "agricultural promotion",      # 02 ส่งเสริมกสิกรรม
    "LVB":    "lao viet",                    # 03 ลาว-เวียด
    "JDB":    "joint development",            # 04 ร่วมพัฒนา
    "BIC":    "bic bank",                    # 05 บีไอซี ลาว
    "IDB":    "indochina",                   # 06 อินโดจีน
    "MJB":    "maruhan",                     # 07 มารุฮัง เจแปน ลาว
    # 08 KBank in Laos — เจ้าของสั่งข้าม (ไม่มีลูกค้าลาวใช้) 17 ส.ค. 2026
    "VTB":    "vietinbank",                  # 09 เวียดตินแบงก์ ลาว
    "MB":     "military commercial",         # 10 มิลิทารี คอมเมอร์เชียล (เพิ่มรหัสฝั่ง Vela)
    "ACLEDA": "acleda",                      # 11 อาเซลีดา ลาว
    "PSVB":   "phongsavanh",                 # 12 พงสะหวัน
    "BOCHK":  "bank of china",               # 13 แบงก์ออฟไชน่า ฮ่องกง (เพิ่มรหัสฝั่ง Vela)
    "SACOM":  "sacombank",                   # 14 ซาคอมแบงก์ ลาว (เพิ่มรหัสฝั่ง Vela)
    "STB":    "stb bank",                    # 15 เอสที
    "BFL":    "franco-lao",                  # 16 ฝรั่ง-ลาว
    "UMONEY": "u-money",                     # 17 U-Money
    "LCNB":   "lao china",                   # 18 ลาว-จีน
    "ICBC":   "industrial and commercial",   # 19 ICBC เวียงจันทน์
    # Vela มีรหัสแต่แอป LDB ไม่มี (โอนผ่านบอทไม่ได้ทางนี้): NBB BOL PSB MAYBANK RHB IIB MMONEY ONEPAY
    #   + ธนาคารไทย THB (KBANK/SCB/KTB/BBL) เป็นของร้านบาท คนละบริบท
}
SAME_BANK = {"LDB"}   # โอนภายในธนาคารเดียวกัน = ไม่มีหน้าเลือกธนาคาร ไปหน้ายอดเลย

def log(*a):
    print(time.strftime("%H:%M:%S"), *a, flush=True)

# ───────────────────────── adb helpers ─────────────────────────
def sh(*args, binary=False, timeout=40):
    r = sp.run(ADB + list(args), capture_output=True, timeout=timeout)
    if binary:
        return r.returncode, r.stdout, r.stderr
    return r.returncode, r.stdout.decode("utf-8", "replace"), r.stderr.decode("utf-8", "replace")

def device_ready():
    _, out, _ = sh("get-state")
    return out.strip() == "device"

def rjit(lo, hi):  # หน่วงสุ่ม (คนกดไม่คงที่) + เผลอหยุดคิดบางครั้ง
    d = random.uniform(lo, hi)
    if random.random() < 0.15: d += random.uniform(0.4, 1.5)   # 15% เผลอช้า (มองจอ/ลังเล)
    time.sleep(d)

def think(lo=1.0, hi=2.6):  # จังหวะ "อ่านจอ" ก่อนทำอะไรสำคัญ (คนไม่กดทันที)
    time.sleep(random.uniform(lo, hi))

# ───────────────────────── อ่านโครงหน้าจอ (uiautomator) ─────────────────────────
NODE_RE = re.compile(r'<node\b[^>]*?/?>')
def _attr(seg, name):
    m = re.search(r'\b' + name + r'="([^"]*)"', seg)
    return m.group(1) if m else ""

def dump_tree(retries=3):
    """คืนลิสต์ node: {desc,text,cls,clickable,x1,y1,x2,y2,cx,cy}"""
    for _ in range(retries):
        rc, _, err = sh("shell", "uiautomator", "dump", "/sdcard/ui.xml")
        if rc != 0 or "ERROR" in err.upper():
            rjit(0.6, 1.0); continue
        rc, xml, _ = sh("shell", "cat", "/sdcard/ui.xml")
        if rc != 0 or "<hierarchy" not in xml:
            rjit(0.6, 1.0); continue
        nodes = []
        for seg in NODE_RE.findall(xml):
            b = re.search(r'bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"', seg)
            if not b: continue
            x1, y1, x2, y2 = map(int, b.groups())
            nodes.append({
                "desc": _unesc(_attr(seg, "content-desc")), "text": _unesc(_attr(seg, "text")),
                "cls": _attr(seg, "class"), "clickable": _attr(seg, "clickable") == "true",
                "x1": x1, "y1": y1, "x2": x2, "y2": y2, "cx": (x1 + x2) // 2, "cy": (y1 + y2) // 2})
        if nodes: return nodes
        rjit(0.6, 1.0)
    return []

def _unesc(s):
    return (s.replace("&#10;", "\n").replace("&amp;", "&").replace("&lt;", "<")
             .replace("&gt;", ">").replace("&quot;", '"').replace("&apos;", "'"))

def find_desc(nodes, substr, exact=False):
    for n in nodes:
        d = n["desc"]
        if (d == substr) if exact else (substr and substr in d):
            return n
    return None

def settle_page(tries=6, gap=0.6):
    """รอให้หน้า 'นิ่ง' ก่อนแตะปุ่มสำคัญ — อ่าน 2 ครั้งติดได้เหมือนกัน = หยุดขยับแล้ว
       จำเป็นเพราะปุ่ม Next/Confirm อยู่พิกัดเดียวกัน: แตะ Next แล้วหน้าเปลี่ยนทันที
       ถ้าแตะซ้ำตอนแอปยังเปลี่ยนหน้าอยู่ แอปจะไม่รับ (หรือกินเป็น double-tap)"""
    prev = None
    for _ in range(tries):
        cur = "|".join((n["desc"] or "") for n in dump_tree())
        if prev is not None and cur == prev:
            return
        prev = cur
        time.sleep(gap)

def find_btn(nodes, substr):
    """หา 'ปุ่มที่กดได้จริง' ตามข้อความ — ไม่ใช่ตัวแรกที่เจอ
       🔴 หน้ายืนยันมีคำว่า Confirm 2 จุด: หัวข้อหน้า [287,97] (clickable=false)
          กับปุ่มจริงล่างจอ [0,1330] (clickable=true) · find_desc คืนตัวแรก = หัวข้อ
          บอทแตะหัวข้อ = ไม่มีอะไรเกิดขึ้น แล้วรอหน้า PIN เก้อ (เจ้าของเจอจริง 17 ส.ค. 2026)
       กติกา: เอาเฉพาะ clickable · ถ้ามีหลายตัวเอาตัวล่างสุด (ปุ่มลงมือมักอยู่ท้ายจอ)"""
    hits = [n for n in nodes if substr in (n["desc"] or "") and n["clickable"]]
    if not hits:
        return None
    return sorted(hits, key=lambda n: n["cy"])[-1]

def find_edit(nodes):
    for n in nodes:
        if n["cls"] == "android.widget.EditText":
            return n
    return None

def cur_focus():
    _, out, _ = sh("shell", "dumpsys", "window")
    m = re.search(r'mCurrentFocus=Window\{[^}]*\s(\S+)\}', out)
    return m.group(1) if m else ""

# ───────────────────────── กด/พิมพ์ (มีสุ่ม) ─────────────────────────
def tap(cx, cy, jit=7):
    """แตะแบบคนจริง: ลงนิ้ว → กดค้างสั้น ๆ → นิ้วขยับเล็กน้อย → ยกนิ้ว
       ใช้ input swipe (มี duration) แทน input tap (ที่กดปุ๊บปั๊บทันทีเหมือนหุ่น)"""
    x = cx + random.randint(-jit, jit); y = cy + random.randint(-jit, jit)
    x2 = x + random.randint(-3, 3); y2 = y + random.randint(-3, 3)   # นิ้วเลื่อนนิดตอนกด
    dur = random.randint(45, 150)                                    # เวลากดค้าง (< long-press)
    sh("shell", "input", "swipe", str(x), str(y), str(x2), str(y2), str(dur))
    rjit(0.4, 1.1)

def tap_desc(nodes, substr, exact=False, what=""):
    n = find_desc(nodes, substr, exact)
    if not n: raise StepError("หาไม่เจอบนจอ: " + (what or substr))
    tap(n["cx"], n["cy"]); return n

_orig_ime = None
def type_via_adbkeyboard(text):
    """พิมพ์เข้าช่อง Flutter ผ่าน ADBKeyboard (adb input ธรรมดาไม่ลง)"""
    global _orig_ime
    if _orig_ime is None:
        _, out, _ = sh("shell", "settings", "get", "secure", "default_input_method")
        _orig_ime = out.strip()
    sh("shell", "ime", "set", CFG["adbkeyboard_ime"]); rjit(0.4, 0.9)
    # พิมพ์ทีละ 2 ตัว หน่วง 1–1.5 วิ ต่อครั้ง (เจ้าของสั่ง 17 ส.ค. 2026 "ห้ามพิมรวดเดียว")
    # ช้าลงแบบคนกดจริง — กันแอป/ระบบธนาคารจับว่าเป็นบอทที่พิมพ์เร็วผิดมนุษย์
    i = 0
    while i < len(text):
        sh("shell", "am", "broadcast", "-a", "ADB_INPUT_TEXT", "--es", "msg", text[i:i + 2])
        i += 2
        time.sleep(random.uniform(1.0, 1.5))
    rjit(0.4, 0.9)

def restore_ime():
    global _orig_ime
    if _orig_ime and "adbkeyboard" not in _orig_ime:
        sh("shell", "ime", "set", _orig_ime)

def tap_pin(nodes, pin):
    """แตะแป้น PIN ตามตัวเลข (หาปุ่มจาก content-desc — เผื่อบางจังหวะสลับ)"""
    for ch in str(pin):
        n = find_desc(nodes, ch, exact=True)
        if not n: raise StepError("หาแป้น PIN เลข " + ch + " ไม่เจอ")
        tap(n["cx"], n["cy"], jit=10)
        rjit(0.25, 0.6)

class StepError(Exception): pass

# ───────────────────────── รอหน้าจอ ─────────────────────────
def wait_for(pred, timeout=20, every=1.0):
    t0 = time.time()
    while time.time() - t0 < timeout:
        nodes = dump_tree()
        if pred(nodes): return nodes
        time.sleep(every)
    return None

# ───────────────────────── ประตูพิสูจน์ ─────────────────────────
def norm_name(s):
    s = (s or "").upper()
    for t in ["MR", "MRS", "MS", "MISS", "MR.", "MS.", "นาย", "นาง", "นางสาว"]:
        s = re.sub(r'\b' + re.escape(t) + r'\b', " ", s)
    return re.sub(r'[^A-Z0-9ก-๙]', "", s)

def digits(s): return re.sub(r'\D', "", s or "")

def proof_gate(nodes, job, cfg):
    """เทียบสิ่งที่เห็นบนหน้า Confirm กับใบถอนที่ Vela สั่ง — ต้องผ่านครบทุกข้อ"""
    blob = "\n".join(n["desc"] for n in nodes if n["desc"])
    reasons = []
    # 1) ยอดตรงเป๊ะ
    pay = int(round(float(job["payout"])))
    amt_txt = "{:,}".format(pay)
    amt_ok = (amt_txt in blob) or (amt_txt + ".00" in blob)
    if not amt_ok: reasons.append("ยอดไม่ตรง (ต้องเห็น %s)" % amt_txt)
    # 2) เลขบัญชีผู้รับ: หน้า Confirm ปิดเลขกลาง — เทียบ 4 ตัวหน้า + 4 ตัวท้าย
    da = digits(job["acctNo"])
    acct_ok = len(da) >= 8 and da[:4] in digits(blob.replace("*", "")) and da[-4:] in blob
    # เทียบแบบระวัง: ดูว่ามีสตริงบัญชีที่ขึ้นต้น 4 ตัวแรกและลงท้าย 4 ตัวท้ายของผู้รับ
    acct_ok = _mask_match(blob, da)
    if not acct_ok: reasons.append("เลขบัญชีผู้รับไม่ตรง (%s…%s)" % (da[:4], da[-4:]))
    # 3) ชื่อผู้รับตรง (ธนาคาร resolve มาให้)
    name_ok = bool(job.get("acctName")) and norm_name(job["acctName"]) in norm_name(blob)
    if not name_ok: reasons.append("ชื่อผู้รับไม่ตรง (ต้องเห็น %s)" % job.get("acctName", ""))
    # 4) บัญชีต้นทางต้องเป็นของเรา (กันจ่ายจากบัญชีผิด)
    ds = digits(cfg.get("srcAcct", ""))
    src_ok = (not ds) or _mask_match(blob, ds)
    if not src_ok: reasons.append("บัญชีต้นทางไม่ใช่ที่ตั้งไว้ (%s…%s)" % (ds[:4], ds[-4:]))
    ok = amt_ok and acct_ok and name_ok and src_ok
    return ok, reasons

def _mask_match(blob, d):
    """หาสตริงบัญชีในจอที่ 4 ตัวหน้าและ 4 ตัวท้ายตรงกับ d (เลขกลางถูกปิด *)"""
    if len(d) < 8: return False
    for line in blob.splitlines():
        dl = digits(line.replace("*", ""))
        if line.strip().upper().startswith(("LAK", "THB")) or "*" in line:
            if d[:4] in line and d[-4:] in line:
                return True
    # เผื่อไม่มี * (บางแบงค์โชว์เต็ม)
    return d in digits(blob)

# ───────────────────────── Vela client (HMAC) ─────────────────────────
def vela(action, **kw):
    body = json.dumps(dict(action=action, bot=CFG["bot_id"], **kw), ensure_ascii=False)
    ts = str(int(time.time()))
    sign = hmac.new(CFG["feed_secret"].encode(), (ts + "." + body).encode(), hashlib.sha256).hexdigest()
    req = urllib.request.Request(
        CFG["vela_url"] + "/api/feed/withdraw", data=body.encode("utf-8"), method="POST",
        # ⚠️ ต้องตั้ง User-Agent เอง — ดีฟอลต์ของ Python คือ "Python-urllib/3.x" ซึ่ง Cloudflare
        #    บล็อกด้วย error 1010 (403) ก่อนถึง worker (เจอจริง 17 ส.ค. 2026: claim ได้ 403 รัว ๆ)
        #    ชื่ออะไรก็ได้ที่ไม่ใช่ชื่อไลบรารี CF ปล่อยผ่าน (auth จริงอยู่ที่ HMAC ด้านล่างแล้ว)
        headers={"Content-Type": "application/json", "User-Agent": "VelaAgent/1.0",
                 "X-Feed-Token": CFG["feed_token"],
                 "X-Feed-Ts": ts, "X-Feed-Sign": sign})
    try:
        resp = urllib.request.urlopen(req, timeout=30)
        return json.loads(resp.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        try: return json.loads(e.read().decode() or "{}")
        except Exception: return {"ok": False, "http": e.code}
    except Exception as e:
        log("‼️ ต่อ Vela ไม่ได้:", e); return {"ok": False, "err": str(e)}

# ───────────────────────── ขั้นตอนโอน 1 ใบ ─────────────────────────
def ensure_awake():
    """ปลุกจอ + ปัดปลดล็อก — มือถือทิ้งไว้เดี๋ยวจอดับเอง แล้ว monkey เปิดแอปทับ lockscreen ไม่ได้
       (เจอจริง 17 ส.ค. 2026: dump เห็นแค่นาฬิกา → บอทฟ้อง 'เข้าหน้าแรก LDB ไม่ได้')
       ⚠️ ปัดขึ้นใช้ได้เฉพาะเครื่องที่ไม่ตั้งรหัสล็อกหน้าจอ — เครื่องบอทต้องตั้งไม่ให้ล็อก"""
    _, out, _ = sh("shell", "dumpsys", "power")
    if "mWakefulness=Awake" not in out:
        sh("shell", "input", "keyevent", "224")   # KEYCODE_WAKEUP
        rjit(0.8, 1.4)
    # ยังอยู่ lockscreen (ไม่เห็นแอปไหนโฟกัส) → ปัดขึ้น
    if "Keyguard" in cur_focus() or "NotificationShade" in cur_focus():
        sh("shell", "input", "swipe", "360", "1200", "360", "500", "200")
        rjit(0.8, 1.4)

_last_fresh = [0.0]   # เวลาที่เปิดแอปสด (login) ล่าสุด
def ensure_home(cfg):
    """ให้แอปอยู่หน้าแรก (ล็อกอินด้วย PIN ถ้าจำเป็น)
       🔴 LDB เปิดค้างนาน → state เพี้ยน/LAPNET error (เจ้าของยืนยัน 17 ส.ค. 2026)
          → ปิดแอปแบบ kill (force-stop) แล้วเปิดใหม่ + login เป็นระยะ (restart_every_sec)
       แยก 2 สถานะ: session หมด → 'Enter PIN' บอทใส่เองได้ · หลุดเต็ม → 'Login/Register' ต้องคนเข้าไป"""
    ensure_awake()   # จอดับ = เปิดแอปไม่ขึ้น ต้องปลุกก่อนเสมอ
    stale = (time.time() - _last_fresh[0]) > CFG.get("restart_every_sec", 180)
    if stale:
        log("  ♻️ ปิดแอป LDB แบบ kill แล้วเปิดใหม่ (กันค้าง/LAPNET จากเปิดนาน)")
        sh("shell", "am", "force-stop", CFG["ldb_pkg"]); rjit(1.5, 2.5)
    sh("shell", "monkey", "-p", CFG["ldb_pkg"], "-c", "android.intent.category.LAUNCHER", "1")
    rjit(3.5, 5.0) if stale else rjit(2.0, 3.0)   # เปิดเย็น ๆ ต้องรอโหลดนานกว่า
    # 🔴 ห้ามตัดสินจาก dump ครั้งเดียว — ระหว่างแอป resume/มีอนิเมชัน uiautomator dump
    #    คืนค่าไม่ทัน/ว่าง แล้วบอทฟ้อง "เข้าหน้าแรกไม่ได้" ทั้งที่หน้าปกติ (เจอจริง 17 ส.ค. 2026)
    #    รอจนเห็นหน้าใดหน้าหนึ่งที่รู้จัก (หน้าแรก / ขอ PIN / หลุดล็อกอิน) ค่อยตัดสิน
    nodes = wait_for(lambda ns: find_desc(ns, CFG["transfer_desc"]) or find_desc(ns, "Enter PIN")
                     or find_desc(ns, "Register") or find_desc(ns, "Login"), timeout=25) or dump_tree()
    if find_desc(nodes, "Enter PIN"):
        log("  ล็อกอินด้วย PIN…")
        tap_pin(nodes, cfg["pin"])
        nodes = wait_for(lambda ns: find_desc(ns, CFG["transfer_desc"]), timeout=20) or []
    # หลุดล็อกอินเต็ม: เจอปุ่ม Login/Register แต่ไม่มี Transfer = บอทใส่ PIN ก็ไม่พอ
    if not find_desc(nodes, CFG["transfer_desc"]) and \
       (find_desc(nodes, "Register") or find_desc(nodes, "Login")):
        raise AppLoggedOut("แอป LDB หลุดล็อกอิน — ต้องให้คนเปิดแอปล็อกอินใหม่ด้วยรหัส (บอทใส่ PIN อย่างเดียวไม่พอ)")
    if find_desc(nodes, CFG["transfer_desc"]):
        _last_fresh[0] = time.time()   # ถึงหน้าแรกสด — นับเวลาใหม่
    return nodes

def select_bank(nodes, job):
    """หน้า 'Select the bank' — เลือกธนาคารปลายทางตามรหัสที่ Vela ส่งมา (job['bank'])
       ธนาคารในลิสต์ยาว เลื่อนหาได้ (swipe สั้น ๆ ในพื้นที่ลิสต์ กัน fling ปิด sheet)"""
    code = str(job.get("bank", "")).upper()
    key = BANK_MATCH.get(code)
    if not key:
        raise ProofFail("ไม่รู้จักธนาคารปลายทาง '%s' ในแอป LDB (ยังไม่ได้ map/แอปไม่รองรับ)" % code)
    for _ in range(10):
        for n in nodes:
            if key in (n["desc"] or "").lower():
                tap(n["cx"], n["cy"]); rjit(0.8, 1.5)
                return
        # ยังไม่เจอ → เลื่อนลงทีละหน่อย
        sh("shell", "input", "swipe", "360", "1050", "360", "700", "500"); rjit(0.6, 1.0)
        nodes = dump_tree()
        if not find_desc(nodes, "Select the bank"):
            break   # sheet ปิดไปแล้ว
    raise ProofFail("หาธนาคาร '%s' ในลิสต์ไม่เจอ (เลื่อนจนสุดแล้ว)" % code)


def fill_amount_desc(nodes, job):
    """หน้ายอด — ช่องแรก(บนสุด)=ยอด · ช่องล่างสุด(ใต้ Description)=คำอธิบาย (บังคับ)
       🔴 ห้ามใช้ edits[1] เป็น description — นั่นคือช่องทศนิยม (เจ้าของเจอจริง 17 ส.ค.)"""
    edits = sorted([n for n in nodes if n["cls"] == "android.widget.EditText"], key=lambda n: n["cy"])
    if not edits:
        raise StepError("หาช่องกรอกยอดไม่เจอ")
    amt = edits[0]
    tap(amt["cx"], amt["cy"])
    type_via_adbkeyboard(str(int(round(float(job["payout"])))))
    restore_ime(); rjit(0.5, 1.0)
    # description = ช่อง EditText ที่กว้าง (เต็มแถว) และอยู่ล่างสุด — เลี่ยงช่องทศนิยมแคบข้างยอด
    nodes = dump_tree()
    wide = [n for n in nodes if n["cls"] == "android.widget.EditText" and (n["x2"] - n["x1"]) > 300]
    wide.sort(key=lambda n: n["cy"])
    if len(wide) >= 2:
        d = wide[-1]   # ล่างสุด = Description
        tap(d["cx"], d["cy"])
        # LDB บังคับกรอก description → ใส่ 4 ตัวท้ายยูสลูกค้า (ตรวจย้อนได้ว่าสลิปนี้โอนให้ใคร)
        desc = str(job.get("cust4") or "").strip() or "auto"
        type_via_adbkeyboard(desc)
        restore_ime(); rjit(0.4, 0.9)


def do_job(job, cfg):
    log("งานใหม่:", job["id"], "จ่าย", job["payout"], job["currency"], "→",
        job.get("acctName"), job.get("acctNo"), "(" + str(job.get("bank")) + ")")
    if not cfg.get("pin"):
        raise StepError("ยังไม่ได้ตั้ง PIN ในหน้าตั้งค่า Vela")

    nodes = ensure_home(cfg)
    if not find_desc(nodes, CFG["transfer_desc"]):
        raise StepError("เข้าหน้าแรก LDB ไม่ได้ (ล็อกอินไม่ผ่าน?)")

    # Transfer → ช่องบัญชี
    tap_desc(nodes, CFG["transfer_desc"], what="แท็บ Transfer"); rjit(1.0, 1.8)
    nodes = dump_tree()
    ed = find_edit(nodes)
    if not ed: raise StepError("หาช่องกรอกเลขบัญชีไม่เจอ")
    tap(ed["cx"], ed["cy"])
    type_via_adbkeyboard(digits(job["acctNo"]))
    restore_ime(); rjit(0.6, 1.2)

    # Next → (ต่างธนาคาร) หน้าเลือกธนาคาร → หน้ายอด
    nodes = dump_tree()
    nx = find_btn(nodes, "Next") or find_desc(nodes, "Next")
    if not nx: raise StepError("ไม่เจอปุ่ม Next (หลังกรอกบัญชี)")
    tap(nx["cx"], nx["cy"])
    # รอให้เข้าหน้าใดหน้าหนึ่ง: เลือกธนาคาร (ต่างแบงค์) หรือ หน้ายอด (same-bank เช่น LDB→LDB)
    nodes = wait_for(lambda ns: find_desc(ns, "Select the bank") or find_desc(ns, "Amount"), timeout=15)
    if not nodes: raise StepError("ไม่ขึ้นหน้าเลือกธนาคาร/หน้ายอด (บัญชีผิด/แอปค้าง?)")
    if find_desc(nodes, "Select the bank"):
        select_bank(nodes, job)
        # เลือกธนาคารแล้ว → ขึ้นหน้ายอด หรือ เด้ง error จากระบบโอนข้ามแบงค์ (LAPNET)
        nodes = wait_for(lambda ns: find_desc(ns, "Amount") or _has_err(ns), timeout=15)
        if not nodes: raise StepError("เลือกธนาคารแล้วแต่ไม่ขึ้นหน้ายอด")
        if _has_err(nodes):
            # เก็บข้อความ error จริงจากจอก่อนปิด — ไม่งั้นเดาไม่ออกว่าเป็น LAPNET/เน็ต/อย่างอื่น
            msg = " ".join((n["desc"] or "").replace("\n", " ") for n in nodes if _has_err([n]))[:160]
            _dismiss_err(nodes)
            _last_fresh[0] = 0   # แอปน่าจะเพี้ยน → บังคับ kill+login ใหม่ในรอบถัดไป
            raise ProofFail("แอปธนาคารเด้ง error หลังเลือกธนาคาร: " + (msg or "(อ่านข้อความไม่ได้)"))

    # หน้ายอด: ช่องแรก = ยอด, ช่องล่างสุด = Description (บังคับ) — ห้ามใช้ edits[1] (นั่นคือช่องทศนิยม!)
    fill_amount_desc(nodes, job)

    # 🔴 dump ใหม่ก่อนหา Next — พอกรอกยอด+desc คีย์บอร์ดขึ้น/ปิดทำ layout เลื่อน
    #    ปุ่ม Next ย้ายที่ ถ้าใช้ tree เก่าจะ tap พลาด → ไม่ขึ้นหน้ายืนยัน (เจอจริง dry-run 17 ส.ค.)
    settle_page()          # ให้หน้านิ่งก่อน (คีย์บอร์ดปิด/เลย์เอาต์เลื่อนเสร็จ)
    nodes = dump_tree()
    # Next → เจอ error ขั้นต่ำ = จ่ายไม่ได้ ต้องหยุด (ไม่ใช่รอ Confirm เก้อ)
    nx = find_btn(nodes, "Next") or find_desc(nodes, "Next")
    if not nx: raise StepError("ไม่เจอปุ่ม Next (หลังกรอกยอด)")
    tap(nx["cx"], nx["cy"])
    nodes = wait_for(lambda ns: find_desc(ns, "Confirm") or find_desc(ns, "MIN_PER_TRANSFER")
                     or find_desc(ns, "Error") or find_desc(ns, "Okay"), timeout=15)
    if nodes and (find_desc(nodes, "MIN_PER_TRANSFER") or find_desc(nodes, "Error")):
        raise ProofFail("ธนาคารปฏิเสธยอดนี้ (น่าจะต่ำกว่าขั้นต่ำ 1,000 กีบของการโอนต่างธนาคาร)")

    # ── หน้า Confirm → ประตูพิสูจน์ ──
    nodes = wait_for(lambda ns: find_desc(ns, "Confirm"), timeout=15)
    if not nodes: raise StepError("ไม่ขึ้นหน้ายืนยัน")
    think(1.2, 2.8)   # อ่านหน้ายืนยันเหมือนคนก่อนตัดสินใจ
    ok, reasons = proof_gate(nodes, job, cfg)
    if not ok:
        raise ProofFail("ประตูพิสูจน์ไม่ผ่าน: " + " · ".join(reasons))
    log("  ✅ ประตูพิสูจน์ผ่าน (ชื่อ+บัญชี+ยอด+ต้นทางตรง)")

    if CFG["dry_run"]:
        log("  🧪 DRY_RUN — ไม่กดจ่ายจริง · กด Back คืนใบเข้าคิว")
        sh("shell", "input", "keyevent", "4"); rjit(0.5, 1.0)
        sh("shell", "input", "keyevent", "4")
        return {"dry_run": True}

    if CFG.get("manual_confirm"):
        # โหมดกึ่งอัตโนมัติ (ทดสอบ): บอทเตรียมครบ+พิสูจน์ผ่านแล้ว แต่ "คน" เป็นผู้กด Confirm+PIN เอง
        # จากนั้นบอทเก็บสลิป+กลับ home ต่อ — ใช้ดู flow ช่วงหลังจ่ายโดยไม่ให้บอทกดจ่ายเอง
        log("  ✋ รอคุณกด Confirm + ใส่ PIN บนมือถือ (พิสูจน์ผ่านแล้ว บอทจะเก็บสลิป+home ต่อให้)")
        nodes = wait_for(lambda ns: find_desc(ns, "Successful") or find_desc(ns, "Reference"), timeout=120)
        if not nodes: raise PostConfirm("รอหน้าสำเร็จนานเกิน — กด Confirm+PIN หรือยัง?")
    else:
        # กด Confirm → PIN → สำเร็จ (โหมดจ่ายจริงเต็มอัตโนมัติ)
        # 🔴 ปุ่ม Next (หน้ากรอกยอด) กับ Confirm (หน้ายืนยัน) อยู่พิกัดเดียวกัน (360,1406)
        #    แตะ Next แล้วหน้าเปลี่ยนเป็น Confirm ทันที · แตะซ้ำที่เดิมเร็วเกิน แอปยังไม่พร้อมรับ
        #    (หรือกินเป็น double-tap) → ไม่ไปหน้า PIN แล้วบอทรอเก้อ (เจ้าของชี้จุด 17 ส.ค. 2026)
        #    แก้: หยุดให้หน้านิ่งก่อน แล้ว "แตะ → เช็คว่าหน้าเปลี่ยนจริง → ไม่เปลี่ยนก็แตะซ้ำ"
        settle_page()
        nodes = pin_page = None
        for attempt in range(3):
            cur = dump_tree()
            cf = find_btn(cur, "Confirm")
            if not cf:
                # ไม่เจอปุ่มแล้ว = น่าจะออกจากหน้ายืนยันไปแล้ว
                pin_page = wait_for(lambda ns: find_desc(ns, "PIN") or find_desc(ns, "1", exact=True), timeout=10)
                break
            if attempt: log("  ↻ แตะ Confirm ซ้ำ (ครั้งที่ %d) — หน้ายังไม่เปลี่ยน" % (attempt + 1))
            tap(cf["cx"], cf["cy"]); rjit(1.4, 2.2)
            pin_page = wait_for(lambda ns: find_desc(ns, "PIN") or find_desc(ns, "1", exact=True), timeout=12)
            if pin_page: break
        nodes = pin_page
        if not nodes:
            # ไม่ขึ้น PIN — แยกให้ออกว่า "ยังไม่ได้จ่าย" หรือ "อาจจ่ายไปแล้ว"
            now = dump_tree()
            if find_btn(now, "Confirm") and find_desc(now, "Amount"):
                # ยังค้างหน้ายืนยันอยู่ = แตะไม่โดน/แอปไม่รับ → เงินยังไม่ออกแน่นอน
                # ต้องเป็น StepError (คืนคิวได้ปลอดภัย) ไม่ใช่ PostConfirm ที่ไปมาร์คว่าจ่ายแล้ว
                raise StepError("กด Confirm แล้วแอปไม่ตอบ (ยังอยู่หน้ายืนยัน — เงินยังไม่ออก)")
            raise PostConfirm("ไม่ขึ้นหน้า PIN หลังกด Confirm")
        tap_pin(nodes, cfg["pin"])

    nodes = wait_for(lambda ns: find_desc(ns, "Successful") or find_desc(ns, "Reference"), timeout=25)
    if not nodes: raise PostConfirm("ไม่เห็นหน้าสำเร็จ (แต่ PIN ใส่ไปแล้ว — เงินอาจออก)")
    ref = _read_ref(nodes)
    log("  ✅ โอนสำเร็จ ref:", ref or "(อ่านไม่ได้)")

    # เก็บสลิป — หน้าสำเร็จไม่ FLAG_SECURE (พิสูจน์แล้ว 17 ส.ค. 2026) → screencap ตรงได้เลย
    # ง่าย+ชัวร์กว่ากด Save แล้วไล่หาไฟล์ในโฟลเดอร์ · ถ้า screencap พลาดค่อย fallback ไป Save
    slip_b64 = _screencap_b64()
    if not slip_b64:
        try:
            sv = find_desc(nodes, "Save")
            if sv:
                before = _slip_list()
                tap(sv["cx"], sv["cy"]); rjit(1.5, 2.5)
                slip_b64 = _pull_new_slip(before)
        except Exception as e:
            log("  ⚠️ ดึงสลิปไม่ได้:", e)
    # กลับหน้าแรกแอปทุกครั้งหลังเก็บสลิป (เจ้าของสั่ง) — พร้อมรับใบถัดไปจากสถานะสะอาด
    try:
        h = find_desc(nodes, "Home")
        if h: tap(h["cx"], h["cy"]); rjit(1.0, 1.8)
        else: sh("shell", "input", "keyevent", "4")
    except Exception:
        pass
    return {"ref": ref, "slip": slip_b64}

def _screencap_b64():
    """แคปหน้าจอปัจจุบัน → base64 (หน้าสำเร็จ LDB ไม่ FLAG_SECURE จึงได้ภาพจริง)
       ถ้าติด FLAG_SECURE จะได้ภาพดำ — เช็คขนาด/สีคร่าว ๆ แล้วคืน None ให้ fallback"""
    try:
        rc, data, _ = sh("exec-out", "screencap", "-p", binary=True)
        if rc != 0 or len(data) < 5000:
            return None
        return base64.b64encode(data).decode()
    except Exception:
        return None

def _read_ref(nodes):
    for n in nodes:
        for src in (n["desc"], n["text"]):
            m = re.search(r'\bFT[0-9A-Z]{6,}\b', src or "")
            if m: return m.group(0)
    return ""

def _slip_list():
    _, out, _ = sh("shell", "ls", "-t", CFG["slip_dir"] + "/")
    return [l.strip() for l in out.splitlines() if l.strip()]

def _pull_new_slip(before):
    after = _slip_list()
    new = [f for f in after if f not in before] or after[:1]   # ไฟล์ใหม่สุด
    if not new: return None
    remote = CFG["slip_dir"] + "/" + new[0]
    rc, data, _ = sh("exec-out", "cat", shlex.quote(remote), binary=True)
    if rc != 0 or len(data) < 100: return None
    return base64.b64encode(data).decode()

ERR_WORDS = ("Sorry", "went wrong", "LAPNET", "Something went", "Error (", "failed", "Failed")
def _has_err(nodes):
    """หน้าเด้ง error (ระบบโอนข้ามแบงค์ LAPNET / ธนาคารปฏิเสธ)"""
    blob = " ".join((n["desc"] or "") for n in nodes)
    return any(w in blob for w in ERR_WORDS)

def _dismiss_err(nodes):
    """กดปิดกล่อง error (ปุ่ม Okay/OK/ตกลง) เพื่อไม่ให้ค้างขวางใบถัดไป"""
    for w in ("Okay", "OK", "ตกลง", "Close"):
        n = find_desc(nodes, w, exact=True)
        if n: tap(n["cx"], n["cy"]); rjit(0.5, 1.0); return
    sh("shell", "input", "keyevent", "4")

class ProofFail(Exception): pass
class PostConfirm(Exception): pass
class AppLoggedOut(Exception): pass   # แอปหลุดล็อกอินเต็ม — ต้องคนเข้าไปล็อกอินใหม่

# ───────────────────────── main loop ─────────────────────────
def run_once():
    if not device_ready():
        log("‼️ มือถือยังไม่ต่อ (adb get-state != device)"); return False
    r = vela("claim")
    if not r.get("ok"):
        log("claim ไม่ผ่าน:", r); return False
    if r.get("enabled") is False:
        log("บอทถอนปิดอยู่ (wd_bot_enabled) — รอเปิดที่หน้าตั้งค่า Vela"); return False
    job = r.get("job")
    if not job:
        return False   # ไม่มีงาน
    cfg = r.get("cfg") or {}
    try:
        res = do_job(job, cfg)
        if res.get("dry_run"):
            vela("fail", id=job["id"], why="DRY_RUN ทดสอบ (พิสูจน์ผ่าน ไม่จ่ายจริง)")
        else:
            out = vela("sent", id=job["id"], ref=res.get("ref", ""), slip=res.get("slip") or "")
            log("  แจ้ง Vela sent:", out)
    except AppLoggedOut as e:
        # แอปหลุดล็อกอิน — คืนคิว + แจ้ง Vela เด่น ๆ (หน้าตั้งค่าจะได้เห็นว่าต้องคนไปล็อกอิน)
        # ไม่วนรัว: หน่วงยาวขึ้นให้คนมีเวลาจัดการ (main loop จะ sleep นานเพราะ worked=False path)
        log("  🔴🔴 " + str(e)); vela("fail", id=job["id"], why="APP_LOGGED_OUT: " + str(e))
        try: vela("hb", model=CFG.get("bot_model", ""), app="logged_out")
        except Exception: pass
        return False   # ให้ main loop หน่วงยาว (poll_sec+) ไม่รัว claim ทั้งที่แอปเข้าไม่ได้
    except ProofFail as e:
        # แก้ไม่ได้ด้วยการลองใหม่ (ธนาคารปฏิเสธ/ยอดต่ำกว่าขั้นต่ำ/ไม่รู้จักแบงค์/พิสูจน์ไม่ผ่าน)
        # → hard=True ให้ Vela ส่งต่อคน ไม่คืนเข้าคิวให้บอทวนหยิบใบเดิมซ้ำไม่จบ
        log("  🛑", e); vela("fail", id=job["id"], why=str(e), hard=True)
    except PostConfirm as e:
        # กด Confirm ไปแล้ว — ห้ามสั่งคืนคิว (กันจ่ายซ้ำ) ให้คนเช็ค
        log("  ⚠️ หลังกดจ่าย:", e); vela("sent", id=job["id"], ref="", slip="")
    except StepError as e:
        log("  ✋ ก่อนกดจ่าย:", e); vela("fail", id=job["id"], why=str(e))
    except Exception as e:
        log("  ‼️ ผิดพลาดไม่คาดคิด (ก่อนจ่าย):", e); vela("fail", id=job["id"], why="agent error: " + str(e))
    finally:
        restore_ime()
    return True

def selftest():
    log("=== SELFTEST ===")
    log("device:", "พร้อม" if device_ready() else "ยังไม่ต่อ")
    log("focus:", cur_focus())
    nodes = dump_tree()
    log("อ่าน node ได้:", len(nodes), "ตัว")
    t = find_desc(nodes, CFG["transfer_desc"])
    log("เจอแท็บ Transfer:", ("ที่ (%d,%d)" % (t["cx"], t["cy"])) if t else "ไม่เจอ (เปิดแอป LDB หน้าแรกก่อน)")
    log("Vela claim:", vela("claim"))

def load_config(path):
    with open(path, encoding="utf-8") as f: user = json.load(f)
    CFG.update(user)
    global ADB
    ADB = shlex.split(CFG["adb"])
    # ตรวจ feed_token/secret ให้ครบ + เป็นของจริง ไม่ใช่ค่าตัวอย่างที่ยังไม่ได้แก้
    # (ค่าตัวอย่างเป็นข้อความไทย <<โทเคน...>> → urllib ใส่ลง header ไม่ได้ ฟ้อง latin-1 งง ๆ)
    for key, thai in (("feed_token", "โทเคนฟีด (feed_token)"), ("feed_secret", "รหัสลับฟีด (feed_secret)")):
        v = str(CFG.get(key, ""))
        if not v or v.startswith("<<") or not v.isascii():
            log("‼️ ยังไม่ได้ใส่ " + thai + " จริงในไฟล์ config.json")
            log("   เปิด config.json ด้วย Notepad แล้ววาง 2 ค่านี้จากหน้าตั้งค่า Vela")
            log("   (การ์ด 'บอทถอนอัตโนมัติ LDB' → แถบ '🔑 รหัสสำหรับใส่ในบอท')")
            sys.exit(1)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    load_config(a.config)
    log("LDB agent เริ่ม · bot=%s · dry_run=%s · vela=%s" % (CFG["bot_id"], CFG["dry_run"], CFG["vela_url"]))
    if a.selftest: return selftest()
    if a.once: return (run_once() or log("ไม่มีงาน"))
    last_hb = [0.0]
    def beat():   # รายงานตัวให้ Vela รู้ว่าออนไลน์ (หน้าตั้งค่าจะโชว์สถานะ) — ทุก ~30 วิ
        if time.time() - last_hb[0] < 30: return
        last_hb[0] = time.time()
        try: vela("hb", model=CFG.get("bot_model", ""))
        except Exception: pass
    while True:
        try:
            beat()
            worked = run_once()
        except KeyboardInterrupt:
            log("หยุด"); break
        except Exception as e:
            log("loop error:", e); worked = False
        time.sleep(random.uniform(CFG["poll_sec"], CFG["poll_sec"] + 3) if not worked else random.uniform(1, 3))

if __name__ == "__main__":
    main()
